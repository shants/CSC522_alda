########
# HW4 
# Instructor: Dr. Thomas Price
# Specify your team details here
# Shrijeet Joshi --> sjoshi22
# Darpan Dodiya --> dpdodiya
# Shantanu Sharma --> ssharma
# 
#########
library(dplyr)
library(ggplot2)

alda_calculate_sse <- function(data_df, cluster_assignments){
  # Calculate overall SSE
  # Input:
    # data_df: data frame that has been given to you by the TA (x,y attributes)
    # cluster_assignments: cluster assignments that have been generated using any of the clustering algorithms
  # Output:
    # A single value of type double, which is the total SSE of the clusters.
  #View(data_df)
  #View(cluster_assignments)
  #return(sum( data_df - cluster_assignments)^2/length(data_df))
  
  sseVal<-0
  centroids<-data.frame(x_mean=numeric(),y_mean=numeric(),count=numeric(),stringsAsFactors = FALSE)
  for(i in 1:length(cluster_assignments))
  {
    if(NROW(centroids)<cluster_assignments[i])
    {
      centroids<-rbind(centroids,c(data_df[i,1],data_df[i,2],1))
    }
    else
    {
      centroids[cluster_assignments[i],1]<-centroids[cluster_assignments[i],1]+data_df[i,1]
      centroids[cluster_assignments[i],2]<-centroids[cluster_assignments[i],2]+data_df[i,2]
      centroids[cluster_assignments[i],3]<-centroids[cluster_assignments[i],3]+1
    }
    
  }
  for(i in 1:NROW(centroids))
  {
    centroids[i,1]<-centroids[i,1]/centroids[i,3]
    centroids[i,2]<-centroids[i,2]/centroids[i,3]
  }
  for(i in 1:NROW(data_df))
  {
    x1=data_df[i,1]
    y1=data_df[i,2]
    x2=centroids[cluster_assignments[i],1]
    y2=centroids[cluster_assignments[i],2]
    distance <- function(x1,y1,x2,y2) (((x1 - x2) ^ 2) + ((y1 - y2) ^ 2))
    sseVal<-sseVal+distance(x1,y1,x2,y2)
  }
  return(sseVal)
}


calElbow <- function(k_value , data_df){
  kmeans_result <- alda_cluster(data_df = data_df, n_clusters = k_value, clustering_type = "kmeans")
  kmeans_sse <- alda_calculate_sse(data_df = data_df, cluster_assignments = kmeans_result)
  return(kmeans_sse)
}
alda_kmeans_elbow_plot <- function(data_df, k_values){
  # ~ 8-10 lines
  # Input:
    # data_df: Original data frame supplied to you by the TA
    # k_values: A vector of values of k for k means clustering
  
  # General Information:
    # Run k means for all the values specified in k_values, generate elbow plot
    # Use alda_cluster with kmeans as your clustering type
    # (you can see an example this function call in hw4_checker.R for k = 2, now repeat it for all k_values)
  
  # Output:
    # Nothing, simply generate a plot and save it to disk as "GroupNumber_elbow.png"
  sseVector <- sapply(k_values, calElbow,data_df)
  #plot(sseVector)
  plot(sseVector,elbow.obj=NULL,xlab="k",
         ylab="Explained_Variance",type="b",pch=20,col.abline="red",
         lty.abline=3,if.plot.new=TRUE,print.info=TRUE)
  print(sseVector)
 
  
}


alda_cluster <- function(data_df, n_clusters, clustering_type){
  set.seed(100) # this is v. important from reproducibility point of view
  # Perform specified clustering
  
  # Inputs:
  # data_df: The dataset provided to you, 2-dimensional (x1,x2)
  # n_clusters: number of clusters to be created
  # clustering_type: can be one of "kmeans" or "single-link" or "complete-link"
  
  # Outputs:
  # Cluster assignments for the specified method (vector, with length = nrow(data_df) and values ranging from 1 to n_clusters)
  if(clustering_type == "kmeans"){
    # ~ 1-2 lines
    # allowed packages for kmeans: R-base, stats, dplyr
    # set the max number of iterations to 100, number of random restarts = 1 (let's not break the TA's computer! )
    # choose "Lloyd" as the algorithm 
    kmeansObj <- kmeans(data_df, n_clusters, iter.max = 100, nstart = 1,algorithm = c("Lloyd"), trace=FALSE)
    # plot(kmeansObj)
    
    return(c(fitted(kmeansObj, method = c("classes"))))
    
    
  }else if(clustering_type == "single-link"){
    # ~ 3-5 lines
    # Allowed packages for single-link: R-base, stats, dplyr
    # Use euclidean distance for distance calculation (Hint: Look at dist method from stats package)
    # Note 1: Can you use the data_df directly for hclust, or do you need to compute something first?
            # What does 'd' mean in hclust? 
    # Note 2: Does hclust return the clusters assignments directly, or does it return a dendrogram? 
            # Hint 2: Look up the stats package for a method to cut the tree at n_clusters
            # Visualize the dendrogram - paste this dendrogram in your PDF 
    singleClusters <- hclust(dist(data_df, method = "euclidean"), method = "single")
    singleCutTree <- cutree(singleClusters, k = n_clusters)
    #View(singleCutTree)
    #plot(singleCutTree)
    #plot(singleClusters, hang = -1, cex = 0.6)
    return(c(singleCutTree))
    
    
  }else{ #complete link clustering is default
    # ~ 3-5 lines
    # Allowed packages for single-link: R-base, stats, dplyr
    # Use euclidean distance for distance calculation (Hint: Look at dist method from stats package)
    # Note 1: Can you use the data_df directly for hclust, or do you need to compute something first?
    # What does 'd' mean in hclust? 
    # Note 2: Does hclust return the clusters assignments directly, or does it return a dendrogram? 
    # Hint 2: Look up the stats package for a method to cut the dendrogram at n_clusters
    # Visualize the dendrogram - paste this dendrogram in your PDF 
    
    completeClusters <- hclust(dist(data_df, method = "euclidean"), method = "complete")
    completeCutTree <- cutree(completeClusters, k = n_clusters)
    #View(completeCutTree)
    plot(completeClusters, hang = -1, cex = 0.6)
    
    return(c(completeCutTree))
    
    
      
  }
}



alda_nn <- function(x_train, x_test, y_train, parameter_grid){
  set.seed(100) # this is v. important from reproducibility point of view
  # ~4-7 lines
  # Perform classification using artificial neural networks using the nnet library
  
  # Inputs:
  # x_train: training data frame(4 variables, x1-x4)
  # x_test: test data frame(4 variables, x1-x4)
  # y_train: dependent variable for training data (can be one of the following classes: 0,1,2)
  # parameter_grid: grid of parameters has already been given to you in hw4_checker
  #View(x_train)
  #View(x_test)
  #View(y_train)
  # General information
  # Both training data and test data have already been scaled - so you don't need to scale it once again.
  # 1. Use the nnet library 
  # 2. Perform 10 fold cross validation without replacement using caret and nnet
  # 3. Note that I am giving you x_train and x_test as separate variables - do you need to combine them like you did in the previous hws?
  # 4. Perform training using 10-fold cross validation without replacement:
    # 4.1  Use accuracy as your metric
    # 4.2  Use nnet as your method
    # 4.3  Use parameter_grid as your grid
  # 5. Predict using the trained model on the test dataset (x_test)
  
  
  
  # Output:
  # A list with two elements, first element = model generated, 
  # second element = predictions on test data (factor)
  
  # NOTE 1: doing as.vector(as.factor(...)) turns it into numeric datatype.
  # NOTE 2: Best way to ensure that your output is of type factor, with the same levels is factor(your_variable, levels=c(specify all your levels here))
  # NOTE 3: If you want to know the best parameters caret chose for you, you can just do print(your trained model using caret), which will print out the final values used for the model
  # NOTE 4: Setting trace = TRUE could help you get insight into how the procedure is done, but set it to FALSE when submitting to reduce clutter 
  # NOTE 5: Remember, there is a penalty for unnecessary print/View function calls in your code.
  # Methods you need to read about:
  # train() (from caret), predict(), nnet()
  
  # allowed packages: R-base, nnet, caret, dplyr
  #my.grid <- expand.grid(.decay = c(0.5, 0.1), .size = c(5, 6, 7))
  #prestige.fit <- train(income ~ prestige + education, data = prestige.train,
                       #method = "nnet", maxit = 1000, tuneGrid = my.grid, trace = F, linout = 1)   
  
  train_control <- trainControl(method="cv", number=10)
  fit <- train(x_train,y_train, method = "nnet", maxit = 10, tuneGrid = parameter_grid, trace = F , trControl=train_control)   
  print(fit)
  predict <- predict(fit, newdata = x_test)
  #View(predict)
  return(list(fit,predict ))

  
}


